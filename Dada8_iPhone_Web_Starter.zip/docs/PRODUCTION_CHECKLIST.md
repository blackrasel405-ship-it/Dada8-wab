# Production checklist

- [ ] Choose authentication provider and implement registration, login, email/phone verification, and recovery.
- [ ] Add database migrations and least-privilege database credentials.
- [ ] Add authenticated API routes; enforce authorization on the server.
- [ ] Make score submission server-validated; use round IDs, expiry, rate limits, replay protection, and anomaly detection.
- [ ] Implement an append-only points ledger; never trust a client-submitted balance.
- [ ] Protect admin routes with MFA, roles, audit logs, and secure session handling.
- [ ] Add privacy policy, terms, support contact, retention/deletion workflow, backups, monitoring.
- [ ] Test on real Android devices and multiple browser sizes.
- [ ] Build and sign Android release APK/AAB using a protected signing key.
- [ ] Review Bangladesh law and applicable store policies before any cash prizes, payments, or redeemable rewards.
