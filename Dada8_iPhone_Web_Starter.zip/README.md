# Dada8 — Skill Gaming Starter (Android + Web + API + Admin)

This is a starter project, not a production-ready or signed APK.

## Included
- Flutter client: Bengali UI, blue/gold theme, home, profile, skill game, local demo points
- Node.js/Express API starter: health endpoint and example leaderboard endpoint
- PostgreSQL schema for users, scores, and point ledger
- Lightweight admin dashboard starter (static HTML)
- Android and Web build instructions

## 1. Run the Flutter app
Install Flutter SDK and Android Studio (for Android builds) or Chrome (for Web).

```bash
flutter create dada8
```
Copy `flutter/lib/main.dart` into the generated project's `lib/main.dart`, then:
```bash
cd dada8
flutter pub get
flutter run
```
Web:
```bash
flutter run -d chrome
```
Android APK:
```bash
flutter build apk --release
```
Expected output: `build/app/outputs/flutter-apk/app-release.apk`

Note: this starter ZIP contains the Flutter source, not a prebuilt APK. APK compilation requires a Flutter/Android build environment.

## 2. Run the API
Install Node.js 20+ and PostgreSQL 15+.
```bash
cd server
cp .env.example .env
npm install
npm run dev
```
Configure `DATABASE_URL` in `.env` before connecting to PostgreSQL. Apply `schema.sql` manually with `psql "$DATABASE_URL" -f schema.sql`.
The API currently provides a health route and a demo leaderboard route. It is intentionally not yet wired to the Flutter app.

## 3. Admin dashboard
Open `admin/index.html` in a browser. It is a visual starter only and uses demo data. Do not expose it as a live admin tool until authentication, role checks, audit logging, and server-side APIs are implemented.

## Production checklist
Before real users:
- Implement verified authentication and password reset.
- Keep secrets on the server; never ship admin keys in the app.
- Add authorization for every API route and admin action.
- Use server-authoritative score validation and anti-cheat checks.
- Add rate limits, audit logs, backups, monitoring, privacy policy and terms.
- Use HTTPS and secure deployment secrets.
- Review applicable laws and app-store policies before offering prizes or payments.
- No real-money wagering, cash-out, or payment flows are implemented here.


## iPhone-only Web publishing

See `IPHONE_WEB_GUIDE.md`. The added GitHub Actions workflow builds the Flutter web UI and deploys it to GitHub Pages without installing Flutter on your iPhone.
