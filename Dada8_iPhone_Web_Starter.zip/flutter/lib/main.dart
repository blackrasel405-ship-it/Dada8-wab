import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const Dada8App());

const navy = Color(0xFF101D58);
const deepBlue = Color(0xFF1B2B69);
const blue = Color(0xFF294BA8);
const gold = Color(0xFFFFC94A);
const paleGold = Color(0xFFFFE8A3);

class Dada8App extends StatelessWidget {
  const Dada8App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Dada8',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: navy,
      colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
      appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
    ),
    home: const DadaHome(),
  );
}

class DadaHome extends StatefulWidget {
  const DadaHome({super.key});
  @override
  State<DadaHome> createState() => _DadaHomeState();
}

class _DadaHomeState extends State<DadaHome> {
  int tab = 0;
  int points = 675;
  int bestTapScore = 0;
  final List<int> recentScores = [];
  String notice = 'স্বাগতম! দক্ষতার চ্যালেঞ্জ খেলো, নিজের স্কোর বাড়াও।';

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: IndexedStack(index: tab, children: [
      _home(),
      _challenges(),
      _leaderboard(),
      _profile(),
    ])),
    bottomNavigationBar: NavigationBar(
      backgroundColor: const Color(0xFF182A70),
      indicatorColor: gold.withOpacity(.22),
      selectedIndex: tab,
      onDestinationSelected: (v) => setState(() => tab = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_rounded), label: 'হোম'),
        NavigationDestination(icon: Icon(Icons.sports_esports), label: 'চ্যালেঞ্জ'),
        NavigationDestination(icon: Icon(Icons.emoji_events), label: 'র‍্যাঙ্কিং'),
        NavigationDestination(icon: Icon(Icons.person), label: 'প্রোফাইল'),
      ],
    ),
  );

  Widget _home() => CustomScrollView(slivers: [
    SliverToBoxAdapter(child: Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 22),
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [blue, navy], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 46, height: 46, decoration: BoxDecoration(color: gold, borderRadius: BorderRadius.circular(14)),
            child: const Icon(Icons.bolt, color: navy, size: 30)),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Dada8', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: paleGold)),
            Text('দক্ষতার খেলায় এগিয়ে যাও', style: TextStyle(color: Colors.white70, fontSize: 12)),
          ])),
          IconButton(onPressed: () => setState(() => notice = 'নোটিফিকেশন এখন ডেমো মোডে আছে।'),
            icon: const Icon(Icons.notifications_none)),
        ]),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF344F9D), deepBlue]),
            border: Border.all(color: gold.withOpacity(.5)),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(children: [
            const CircleAvatar(radius: 27, backgroundColor: gold, child: Icon(Icons.person, color: navy, size: 30)),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('খেলোয়াড়', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
              Text('দক্ষতা অনুশীলন করো', style: TextStyle(color: Colors.white70, fontSize: 12)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              const Text('ডেমো পয়েন্ট', style: TextStyle(color: Colors.white70, fontSize: 11)),
              Text('$points', style: const TextStyle(color: gold, fontWeight: FontWeight.w900, fontSize: 22)),
            ]),
          ]),
        ),
      ]),
    )),
    SliverToBoxAdapter(child: Padding(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
      child: Container(padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: deepBlue, borderRadius: BorderRadius.circular(14)),
        child: Row(children: [const Icon(Icons.campaign, color: gold), const SizedBox(width: 10),
          Expanded(child: Text(notice, style: const TextStyle(fontSize: 13)))])),
    )),
    SliverToBoxAdapter(child: Padding(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
      child: Row(children: [
        const Expanded(child: Text('দক্ষতার গেম', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
        TextButton(onPressed: () => setState(() => tab = 1), child: const Text('সব দেখো')),
      ]),
    )),
    SliverPadding(padding: const EdgeInsets.symmetric(horizontal: 18),
      sliver: SliverList(delegate: SliverChildListDelegate([
        _gameCard('দ্রুত ট্যাপ', 'সময় ধরে দ্রুত ট্যাপ করো', Icons.touch_app, const Color(0xFF3478F6), () => _launchTapGame()),
        _gameCard('মেমোরি ম্যাচ', 'কার্ডের অবস্থান মনে রাখো', Icons.grid_view_rounded, const Color(0xFF8B5CF6), () => _comingSoon('মেমোরি ম্যাচ')),
        _gameCard('দ্রুত গণিত', 'সঠিক উত্তর বেছে নাও', Icons.calculate, const Color(0xFF00AFA6), () => _comingSoon('দ্রুত গণিত')),
      ]))),
    const SliverToBoxAdapter(child: Padding(
      padding: EdgeInsets.fromLTRB(18, 18, 18, 28),
      child: Text('ডেমো সংস্করণ • পয়েন্টের কোনো নগদ মূল্য নেই', textAlign: TextAlign.center,
        style: TextStyle(color: Colors.white54, fontSize: 11)),
    )),
  ]);

  Widget _gameCard(String title, String subtitle, IconData icon, Color color, VoidCallback onPlay) =>
    Container(margin: const EdgeInsets.only(bottom: 13),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [color.withOpacity(.95), deepBlue], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white.withOpacity(.10))),
      child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
        Container(width: 56, height: 56, decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(16)),
          child: Icon(icon, color: gold, size: 31)),
        const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4), Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.white70)),
        ])),
        const SizedBox(width: 8),
        FilledButton(onPressed: onPlay, style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: navy),
          child: const Text('খেলো')),
      ])));

  Widget _challenges() => _page('চ্যালেঞ্জ', 'দক্ষতাভিত্তিক গেম বেছে নিয়ে অনুশীলন করো.', [
    ListTile(leading: const Icon(Icons.touch_app, color: gold), title: const Text('দ্রুত ট্যাপ'), subtitle: const Text('১০ সেকেন্ডে দ্রুত ট্যাপ'), trailing: const Icon(Icons.chevron_right), onTap: _launchTapGame),
    ListTile(leading: const Icon(Icons.grid_view, color: gold), title: const Text('মেমোরি ম্যাচ'), subtitle: const Text('পরবর্তী সংস্করণে আসছে'), onTap: () => _comingSoon('মেমোরি ম্যাচ')),
    ListTile(leading: const Icon(Icons.calculate, color: gold), title: const Text('দ্রুত গণিত'), subtitle: const Text('পরবর্তী সংস্করণে আসছে'), onTap: () => _comingSoon('দ্রুত গণিত')),
  ]);

  Widget _leaderboard() => _page('র‍্যাঙ্কিং', 'এই ডিভাইসে খেলা সাম্প্রতিক স্কোর', [
    if (recentScores.isEmpty) const ListTile(leading: Icon(Icons.info_outline, color: gold), title: Text('এখনো কোনো স্কোর নেই'), subtitle: Text('একটি চ্যালেঞ্জ খেলে শুরু করো।')),
    ...recentScores.asMap().entries.map((e) => ListTile(
      leading: CircleAvatar(backgroundColor: gold, foregroundColor: navy, child: Text('${e.key + 1}')),
      title: Text('তোমার স্কোর'), trailing: Text('${e.value}', style: const TextStyle(color: gold, fontWeight: FontWeight.bold)))),
    const ListTile(leading: Icon(Icons.cloud_outlined), title: Text('অনলাইন র‍্যাঙ্কিং'), subtitle: Text('সার্ভার সংযোগ যোগ হলে সক্রিয় হবে')),
  ]);

  Widget _profile() => _page('প্রোফাইল', 'Dada8 ডেমো অ্যাকাউন্ট', [
    const SizedBox(height: 10),
    const CircleAvatar(radius: 38, backgroundColor: gold, child: Icon(Icons.person, color: navy, size: 44)),
    ListTile(leading: const Icon(Icons.stars, color: gold), title: const Text('ডেমো পয়েন্ট'), trailing: Text('$points')),
    ListTile(leading: const Icon(Icons.emoji_events, color: gold), title: const Text('সেরা ট্যাপ স্কোর'), trailing: Text('$bestTapScore')),
    const ListTile(leading: Icon(Icons.lock_outline), title: Text('অ্যাকাউন্ট নিরাপত্তা'), subtitle: Text('অনলাইন লগইন এখনো যুক্ত হয়নি')),
  ]);

  Widget _page(String title, String subtitle, List<Widget> children) => ListView(padding: const EdgeInsets.all(18), children: [
    Text(title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: paleGold)),
    const SizedBox(height: 6), Text(subtitle, style: const TextStyle(color: Colors.white70)),
    const SizedBox(height: 18), ...children,
  ]);

  void _launchTapGame() => Navigator.of(context).push(MaterialPageRoute(
    builder: (_) => TapGame(onFinish: (score) {
      setState(() { points += score; bestTapScore = score > bestTapScore ? score : bestTapScore; recentScores.insert(0, score); notice = 'চ্যালেঞ্জ শেষ! $score ডেমো পয়েন্ট যোগ হয়েছে।'; });
    }),
  ));

  void _comingSoon(String game) => showDialog(context: context, builder: (ctx) => AlertDialog(
    backgroundColor: deepBlue, title: Text(game),
    content: const Text('এই গেমটি পরবর্তী সংস্করণে যোগ করা হবে।'),
    actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ঠিক আছে'))],
  ));
}

class TapGame extends StatefulWidget {
  final ValueChanged<int> onFinish;
  const TapGame({super.key, required this.onFinish});
  @override
  State<TapGame> createState() => _TapGameState();
}

class _TapGameState extends State<TapGame> {
  int taps = 0;
  int seconds = 10;
  Timer? timer;
  bool started = false;
  bool finished = false;

  void _start() {
    if (started || finished) return;
    setState(() => started = true);
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (seconds <= 1) {
        t.cancel();
        setState(() { seconds = 0; finished = true; });
        widget.onFinish(taps);
        _showResult();
      } else {
        setState(() => seconds--);
      }
    });
  }

  void _showResult() {
    showDialog(context: context, barrierDismissible: false, builder: (ctx) => AlertDialog(
      backgroundColor: deepBlue,
      title: const Text('চ্যালেঞ্জ শেষ!'),
      content: Text('তোমার স্কোর: $taps\\n$taps ডেমো পয়েন্ট যোগ হয়েছে।'),
      actions: [TextButton(onPressed: () { Navigator.pop(ctx); Navigator.pop(context); }, child: const Text('হোমে ফিরো'))],
    ));
  }

  @override
  void dispose() { timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('দ্রুত ট্যাপ চ্যালেঞ্জ')),
    body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(
      mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('১০ সেকেন্ডে যতবার পারো ট্যাপ করো!', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Text(started ? 'বাকি সময়: $seconds সেকেন্ড' : 'শুরু চাপলে টাইমার চলবে',
          style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 20),
        Text('$taps', style: const TextStyle(fontSize: 60, fontWeight: FontWeight.w900, color: gold)),
        const SizedBox(height: 20),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: navy, padding: const EdgeInsets.symmetric(horizontal: 34, vertical: 18)),
          onPressed: finished ? null : () {
            if (!started) { _start(); }
            if (started && seconds > 0) setState(() => taps++);
          },
          child: Text(!started ? 'শুরু / ট্যাপ' : 'ট্যাপ করো', style: const TextStyle(fontSize: 18)),
        ),
        const SizedBox(height: 12),
        const Text('শুধু অনুশীলনের জন্য ভার্চুয়াল পয়েন্ট।', style: TextStyle(color: Colors.white54, fontSize: 12)),
      ],
    ))),
  );
}
