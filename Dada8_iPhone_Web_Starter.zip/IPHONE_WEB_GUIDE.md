# Dada8 Web — iPhone থেকে প্রকাশ করার সহজ নির্দেশনা

এই প্যাকেজে GitHub Actions workflow যোগ করা হয়েছে। এটি GitHub-এ আপলোড করলে Flutter web app স্বয়ংক্রিয়ভাবে build ও GitHub Pages-এ প্রকাশ করার চেষ্টা করবে। কম্পিউটার বা iPhone-এ Flutter SDK লাগবে না।

## iPhone দিয়ে সেটআপ

1. Safari-তে `https://github.com` খুলে সাইন ইন/অ্যাকাউন্ট তৈরি করুন।
2. `+` মেনু থেকে **New repository** নির্বাচন করুন।
3. Repository name দিন `dada8-web`, **Public** নির্বাচন করুন, এবং **Create repository** চাপুন।
4. নতুন repository-তে **Add file → Upload files** চাপুন।
5. iPhone-এর Files app-এ ZIP ফাইলটি আগে Extract করুন। এরপর extracted folder-এর ভেতরের ফাইলগুলো repository-তে আপলোড করুন। `.github/workflows/deploy-web.yml` ফাইলটির folder path যেন ঠিক একই থাকে। যদি iPhone browser দিয়ে পুরো folder structure আপলোড করা কঠিন হয়, নিচের “বিকল্প পদ্ধতি” ব্যবহার করুন।
6. সব ফাইল আপলোড হলে **Commit changes** চাপুন।
7. Repository-তে **Settings → Pages** খুলুন। **Build and deployment → Source**-এ `GitHub Actions` নির্বাচন করুন।
8. **Actions** tab-এ গিয়ে `Build and deploy Dada8 Web` workflow দেখুন। চলমান কাজ শেষ হয়ে সবুজ checkmark হলে **Settings → Pages**-এ প্রকাশিত URL দেখাবে। সাধারণত URL হবে `https://YOUR-USERNAME.github.io/dada8-web/`।
9. URL-টি iPhone Safari-তে খুলুন। চাইলে Share → **Add to Home Screen** করে আইকনের মতো ব্যবহার করতে পারবেন।

## গুরুত্বপূর্ণ

- এই workflow শুধু **ওয়েব UI** প্রকাশ করে। Node API, PostgreSQL database, login, real-money payment বা server-এ score submission এই ওয়েব UI-তে এখনো সংযুক্ত নয়।
- বর্তমান ব্যালান্স/লিডারবোর্ড ডেমো ডেটা; বাস্তব ব্যবহারকারীর ডেটা নয়।
- GitHub Pages-এ repository Public রাখা সবচেয়ে সহজ free পথ। অ্যাকাউন্ট/প্ল্যানভেদে সেটিংস বদলাতে পারে।
- GitHub Pages-এ প্রকাশিত পেজ public হতে পারে—কোনো ব্যক্তিগত তথ্য, password বা API secret commit করবেন না।
- workflow ব্যর্থ হলে **Actions → failed run → Build and deploy Dada8 Web** খুলে লাল error message দেখুন।

## বিকল্প পদ্ধতি (ফাইল আপলোডে সমস্যা হলে)

iPhone Safari-তে GitHub repository খুলে **Code → Codespaces → Create codespace on main** ব্যবহার করা গেলে Codespaces-এর terminal-এ ZIP আপলোড/Extract করে ফাইলগুলো বসানো যায়। Codespaces না থাকলে বা quota চাইলে প্রথম পদ্ধতিতে folder structure ঠিক করে আপলোড করাই ভালো।

## এই ZIP-এর ফাইল

- `flutter/lib/main.dart` — Dada8 UI
- `server/` — backend starter (ওয়েব UI-র সঙ্গে এখনো সংযুক্ত নয়)
- `admin/` — demo admin page
- `.github/workflows/deploy-web.yml` — automatic web build/deploy
- `docs/PRODUCTION_CHECKLIST.md` — production-এর আগে করণীয়
