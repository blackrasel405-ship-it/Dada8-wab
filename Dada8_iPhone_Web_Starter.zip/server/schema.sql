CREATE TABLE IF NOT EXISTS app_users (
  id BIGSERIAL PRIMARY KEY,
  username VARCHAR(32) UNIQUE NOT NULL,
  display_name VARCHAR(80) NOT NULL DEFAULT 'খেলোয়াড়',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS game_scores (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES app_users(id),
  game_key VARCHAR(40) NOT NULL,
  score INTEGER NOT NULL CHECK (score >= 0 AND score <= 100000),
  duration_ms INTEGER NOT NULL CHECK (duration_ms >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_game_scores_game_score
  ON game_scores (game_key, score DESC, created_at ASC);

CREATE TABLE IF NOT EXISTS points_ledger (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES app_users(id),
  delta INTEGER NOT NULL,
  reason VARCHAR(120) NOT NULL,
  reference_score_id BIGINT REFERENCES game_scores(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
