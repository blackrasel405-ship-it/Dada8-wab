import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import pg from 'pg';

const { Pool } = pg;
const app = express();
app.use(cors());
app.use(express.json({ limit: '32kb' }));

const pool = process.env.DATABASE_URL ? new Pool({ connectionString: process.env.DATABASE_URL }) : null;

app.get('/health', (_req, res) => res.json({ ok: true, service: 'dada8-api-starter' }));

app.get('/api/leaderboard', async (req, res) => {
  if (!pool) return res.status(503).json({ error: 'DATABASE_URL is not configured' });
  const game = String(req.query.game || 'tap_challenge').slice(0, 40);
  const limit = Math.min(Math.max(Number.parseInt(req.query.limit || '20', 10) || 20, 1), 100);
  try {
    const result = await pool.query(
      `SELECT u.username, u.display_name, MAX(s.score)::int AS best_score
       FROM game_scores s JOIN app_users u ON u.id = s.user_id
       WHERE s.game_key = $1 AND u.is_active = TRUE
       GROUP BY u.id, u.username, u.display_name
       ORDER BY best_score DESC LIMIT $2`,
      [game, limit]
    );
    res.json({ game, entries: result.rows });
  } catch (err) {
    console.error('leaderboard query failed', err);
    res.status(500).json({ error: 'Unable to load leaderboard' });
  }
});

// Intentionally no public score-submission, auth, wallet, or admin-mutation route yet.
// Add server-side authentication, anti-cheat validation, and authorization before production.
const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`Dada8 API starter listening on :${port}`));
